# DeTACH - Detaching spatial Trascriptomics into Annotated Cells with High confidence

A pre-release of DeTACH is called pytacs and is also available in pypi. No major difference currently. 

```
Copyright (C) 2025 Xindong Liu

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
```

A tool for segmenting/integrating sub-cellular spots in high-resolution spatial
transcriptomics into single-cellular spots and cell-type mapping leveraging paired scRNA-seq.


## Requirements
It could be simply
installed by `pip install pydetach`.

For conda users,

```Bash
conda create -n detach python=3.12 -y
conda activate detach
pip install pydetach
```

For python3 users, first make sure your python is
of version 3.12, and then in your working directory,

```Bash
python -m venv detach
source detach/bin/activate
python -m pip install pydetach
```

To use it for downstream analysis in combination with Squidpy, it is recommended to use a seperate virtual environment to install Squidpy.

## Usage

(Updated in 2025.11.27)

DeTACH now is packed as a commandline tool:

See help:

```
$ python -m pydetach -h
```

If you are interested in using pydetach as a python package, we recommend using pydetach.recipe module.
See docstring therein.

